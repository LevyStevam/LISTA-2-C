#include <stdio.h>

int main(){
    int x=5;
    puts("diferença entre pré incrementar e pos incrementar, exemplo número '5'.");
    printf("número 5 com pós incremento: %d \n", x--);
    printf("número 5 com pré incremento: %d \n", --x);
    return 0;
}
