#include <stdio.h>

int main()
{
    int x,y,z;
    x=150;
    y=110;
    z=0;
    for(z; x >=y ; z++ ){
        x += 2;
        y += 3;
    };
    printf("o pedro vai passar josé em altura em %d anos", z);
    
    return 0;
}
